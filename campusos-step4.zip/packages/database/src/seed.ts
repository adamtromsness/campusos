/**
 * CampusOS Database Seed Script
 *
 * Seeds the platform schema with initial development data:
 * - One test organisation
 * - One test school (subdomain: demo)
 * - Tenant routing record for the demo school
 *
 * Idempotent: safe to run multiple times.
 */

import { getPlatformClient, disconnectAll } from './client';
import { generateId } from './uuid';
import { provisionTenant } from './provision-tenant';

async function main() {
  console.log('🌱 CampusOS seed script');
  console.log('');

  const client = getPlatformClient();

  // ── 1. Create test organisation ────────────────────────────
  const orgId = generateId();
  const existingOrg = await client.organisation.findFirst({
    where: { name: 'Demo School District' },
  });

  let finalOrgId: string;
  if (existingOrg) {
    console.log('  ⏭️   Organisation "Demo School District" already exists');
    finalOrgId = existingOrg.id;
  } else {
    await client.organisation.create({
      data: {
        id: orgId,
        name: 'Demo School District',
        countryCode: 'US',
        orgType: 'DISTRICT',
      },
    });
    console.log('  ✅  Organisation "Demo School District" created');
    finalOrgId = orgId;
  }

  // ── 2. Create test school ──────────────────────────────────
  const schoolId = generateId();
  const existingSchool = await client.school.findFirst({
    where: { subdomain: 'demo' },
  });

  let finalSchoolId: string;
  if (existingSchool) {
    console.log('  ⏭️   School "demo" already exists');
    finalSchoolId = existingSchool.id;
  } else {
    await client.school.create({
      data: {
        id: schoolId,
        organisationId: finalOrgId,
        name: 'Lincoln Elementary',
        subdomain: 'demo',
        countryCode: 'US',
        timezone: 'America/Chicago',
        planTier: 'MEDIUM',
        schemaName: 'tenant_demo',
      },
    });
    console.log('  ✅  School "Lincoln Elementary" (subdomain: demo) created');
    finalSchoolId = schoolId;
  }

  // ── 3. Create tenant routing record ────────────────────────
  const existingRouting = await client.tenantRouting.findFirst({
    where: { tenantId: finalSchoolId },
  });

  if (existingRouting) {
    console.log('  ⏭️   Tenant routing for demo already exists');
  } else {
    await client.tenantRouting.create({
      data: {
        id: generateId(),
        tenantId: finalSchoolId,
        clusterId: 'primary',
        schemaName: 'tenant_demo',
        isActive: true,
        isFrozen: false,
        maxConnectionsPool: 10,
      },
    });
    console.log('  ✅  Tenant routing record created');
  }

  // ── 4. Provision tenant schema ─────────────────────────────
  try {
    await provisionTenant('demo');
  } catch (e) {
    // Schema may already exist from Docker init script — that's fine
    console.log('  ⏭️   Tenant schema already provisioned (or no migrations yet)');
  }

  console.log('');
  console.log('  🟢 Seed complete');
  console.log('');
  console.log('  Test data:');
  console.log('    Organisation: Demo School District');
  console.log('    School:       Lincoln Elementary (subdomain: demo)');
  console.log('    Tenant:       tenant_demo');
}

main()
  .then(() => disconnectAll())
  .then(() => process.exit(0))
  .catch((e) => {
    console.error('Seed failed:', e);
    disconnectAll().then(() => process.exit(1));
  });
