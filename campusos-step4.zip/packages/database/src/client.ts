/**
 * CampusOS Prisma Client Factory
 *
 * Manages two types of database access:
 * 1. Platform client — always targets the platform schema
 * 2. Tenant client — sets search_path to tenant schema + platform + public
 *
 * Architecture (ADR-001, Dev Plan Section 18):
 * - Schema-per-tenant isolation
 * - search_path set per-request: SET search_path TO tenant_<id>, platform, public
 * - Platform queries explicitly target the platform schema
 * - Tenant queries see their own tables first, then fall through to platform
 */

import { PrismaClient } from '@prisma/client';

let platformClient: PrismaClient | null = null;

/**
 * Get the platform Prisma client.
 * This client always operates on the platform schema.
 * Used for: organisations, schools, platform_users, iam_person, etc.
 */
export function getPlatformClient(): PrismaClient {
  if (!platformClient) {
    platformClient = new PrismaClient({
      datasourceUrl: process.env.DATABASE_URL,
      log: process.env.NODE_ENV === 'development' ? ['query', 'warn', 'error'] : ['warn', 'error'],
    });
  }
  return platformClient;
}

/**
 * Create a tenant-scoped Prisma client.
 * Sets the PostgreSQL search_path so queries resolve to the tenant's schema
 * first, then fall through to the platform schema for shared tables.
 *
 * @param schemaName - The tenant's schema name (e.g. 'tenant_demo')
 */
export function createTenantClient(schemaName: string): PrismaClient {
  // Validate schema name to prevent SQL injection
  if (!/^tenant_[a-z0-9_]+$/.test(schemaName)) {
    throw new Error(`Invalid tenant schema name: ${schemaName}`);
  }

  const client = new PrismaClient({
    datasourceUrl: process.env.DATABASE_URL,
    log: process.env.NODE_ENV === 'development' ? ['query', 'warn', 'error'] : ['warn', 'error'],
  });

  // Use Prisma middleware to set search_path before every query
  client.$use(async (params, next) => {
    // Set the search_path for this tenant
    // Order matters: tenant schema first, then platform, then public
    await client.$executeRawUnsafe(
      `SET search_path TO "${schemaName}", platform, public`,
    );
    return next(params);
  });

  return client;
}

/**
 * Execute a raw SQL query against the platform schema.
 * Used for operations that Prisma doesn't support natively
 * (e.g., schema creation, partition management).
 */
export async function executePlatformSQL(sql: string, params: unknown[] = []): Promise<void> {
  const client = getPlatformClient();
  if (params.length > 0) {
    await client.$executeRawUnsafe(sql, ...params);
  } else {
    await client.$executeRawUnsafe(sql);
  }
}

/**
 * Disconnect all Prisma clients.
 * Call during graceful shutdown.
 */
export async function disconnectAll(): Promise<void> {
  if (platformClient) {
    await platformClient.$disconnect();
    platformClient = null;
  }
}
