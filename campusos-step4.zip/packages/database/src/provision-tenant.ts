/**
 * CampusOS Tenant Provisioning
 *
 * Creates a new tenant schema and applies the tenant migration template.
 * Each school gets its own PostgreSQL schema (ADR-001).
 *
 * Usage:
 *   pnpm --filter @campusos/database provision --subdomain=demo
 *   or programmatically: await provisionTenant('demo')
 */

import { getPlatformClient, executePlatformSQL } from './client';
import { readFileSync, readdirSync } from 'fs';
import { join } from 'path';

const TENANT_MIGRATIONS_DIR = join(__dirname, '..', 'prisma', 'tenant', 'migrations');

/**
 * Provision a new tenant schema.
 *
 * 1. Validates the subdomain
 * 2. Creates the PostgreSQL schema
 * 3. Grants permissions to the campusos role
 * 4. Applies all tenant migrations in order
 * 5. Sets the search_path for the schema
 *
 * @param subdomain - The school's subdomain (e.g. 'demo', 'lincoln-high')
 * @returns The schema name that was created (e.g. 'tenant_demo')
 */
export async function provisionTenant(subdomain: string): Promise<string> {
  // Sanitise subdomain → schema name
  const schemaName = `tenant_${subdomain.replace(/-/g, '_').toLowerCase()}`;

  // Validate schema name format
  if (!/^tenant_[a-z0-9_]+$/.test(schemaName)) {
    throw new Error(
      `Invalid subdomain "${subdomain}" — must contain only lowercase letters, numbers, and hyphens.`,
    );
  }

  console.log(`📦 Provisioning tenant schema: ${schemaName}`);

  // Step 1: Create schema
  await executePlatformSQL(`CREATE SCHEMA IF NOT EXISTS "${schemaName}"`);
  console.log(`   ✅ Schema created`);

  // Step 2: Grant permissions
  await executePlatformSQL(`GRANT ALL ON SCHEMA "${schemaName}" TO campusos`);
  console.log(`   ✅ Permissions granted`);

  // Step 3: Apply tenant migrations
  await applyTenantMigrations(schemaName);

  console.log(`   🟢 Tenant ${schemaName} provisioned successfully`);
  return schemaName;
}

/**
 * Apply all tenant migration SQL files to a given schema.
 * Migrations are applied in alphabetical order (use numbered prefixes).
 * Each migration is idempotent — safe to re-run.
 */
async function applyTenantMigrations(schemaName: string): Promise<void> {
  let migrationFiles: string[];

  try {
    migrationFiles = readdirSync(TENANT_MIGRATIONS_DIR)
      .filter((f) => f.endsWith('.sql'))
      .sort();
  } catch {
    console.log(`   ⚠️  No tenant migrations found at ${TENANT_MIGRATIONS_DIR}`);
    return;
  }

  if (migrationFiles.length === 0) {
    console.log(`   ⚠️  No tenant migration files found — empty schema created`);
    return;
  }

  // Set search_path to the tenant schema before applying migrations
  await executePlatformSQL(`SET search_path TO "${schemaName}", platform, public`);

  for (const file of migrationFiles) {
    const sql = readFileSync(join(TENANT_MIGRATIONS_DIR, file), 'utf-8');
    console.log(`   📄 Applying: ${file}`);
    await executePlatformSQL(sql);
  }

  // Reset search_path
  await executePlatformSQL(`SET search_path TO platform, public`);

  console.log(`   ✅ ${migrationFiles.length} migration(s) applied`);
}

/**
 * List all tenant schemas in the database.
 */
export async function listTenantSchemas(): Promise<string[]> {
  const client = getPlatformClient();
  const result = await client.$queryRawUnsafe<Array<{ schema_name: string }>>(
    `SELECT schema_name FROM information_schema.schemata WHERE schema_name LIKE 'tenant_%' ORDER BY schema_name`,
  );
  return result.map((r) => r.schema_name);
}

/**
 * Drop a tenant schema (DANGER — use only in dev/test).
 * Production: schemas are never dropped, only deactivated.
 */
export async function dropTenantSchema(schemaName: string): Promise<void> {
  if (process.env.NODE_ENV === 'production') {
    throw new Error('Cannot drop tenant schemas in production');
  }

  if (!/^tenant_[a-z0-9_]+$/.test(schemaName)) {
    throw new Error(`Invalid tenant schema name: ${schemaName}`);
  }

  await executePlatformSQL(`DROP SCHEMA IF EXISTS "${schemaName}" CASCADE`);
  console.log(`   🗑️  Schema ${schemaName} dropped`);
}

// ── CLI Entry Point ──────────────────────────────────────────

if (require.main === module) {
  const args = process.argv.slice(2);
  const subdomainArg = args.find((a) => a.startsWith('--subdomain='));

  if (!subdomainArg) {
    console.log('Usage: tsx provision-tenant.ts --subdomain=<name>');
    console.log('  e.g. tsx provision-tenant.ts --subdomain=demo');
    process.exit(1);
  }

  const subdomain = subdomainArg.split('=')[1];
  if (!subdomain) {
    console.error('Subdomain cannot be empty');
    process.exit(1);
  }

  provisionTenant(subdomain)
    .then(() => process.exit(0))
    .catch((e) => {
      console.error('Provisioning failed:', e);
      process.exit(1);
    });
}
